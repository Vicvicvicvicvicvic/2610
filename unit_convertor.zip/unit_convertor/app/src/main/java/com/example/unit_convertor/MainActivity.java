package com.example.unit_convertor;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    double celsius, fahrenheit;
    String number1, number2;
    EditText from;
    EditText to;
    EditText userinput;
    TextView ans;
    Button convert;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        from = (EditText) findViewById(R.id.from);
        to = (EditText) findViewById(R.id.to);
        userinput = (EditText) findViewById(R.id.userinput);
        ans = (TextView) findViewById(R.id.ans);
        convert = (Button) findViewById(R.id.button);

        convert.setOnClickListener(new View.OnClickListener() {

            @SuppressLint({"SetTextI18n", "DefaultLocale"})
            @Override

            public void onClick(View view) {
                convert();
            }

            @SuppressLint("SetTextI18n")
            public void convert(){
                number1 = from.getText().toString().trim();
                number2 = to.getText().toString().trim();

                if (number1.equalsIgnoreCase(("Celsius")) && number2.equalsIgnoreCase("fahrenheit")){
                    celsius = Double.parseDouble(userinput.getText().toString());
                    fahrenheit = (celsius * 1.8) + 32;
//                    result.setText(String.format("%.1f", fahrenheit));
                    ans.setText(String.format("%.1f", fahrenheit));
                }

                else if ((number1.equalsIgnoreCase(("fahrenheit")) && number2.equalsIgnoreCase("Celsius"))){
                    fahrenheit = Double.parseDouble(userinput.getText().toString());
                    celsius = (5 * (fahrenheit - 32)) / 9;
                    ans.setText(String.format("%.1f C", celsius));
                }

                else if (number1.equalsIgnoreCase(number2) ){
                    ans.setError("Same input!!");
                    ans.setText("Check your input value");
                }

            }
        });


    }
}